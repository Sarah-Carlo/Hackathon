import Link from "next/link"
import { GraduationCap } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t bg-card px-4 py-12 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="flex flex-col items-center gap-6 md:flex-row md:justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <GraduationCap className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="font-heading text-lg font-bold text-foreground">UniGuide</span>
          </div>

          <nav className="flex flex-wrap justify-center gap-6 text-sm">
            <Link href="/" className="text-muted-foreground transition-colors hover:text-foreground">Home</Link>
            <Link href="/university-finder" className="text-muted-foreground transition-colors hover:text-foreground">Find Universities</Link>
            <Link href="/documents" className="text-muted-foreground transition-colors hover:text-foreground">Documents</Link>
            <Link href="/visa-guide" className="text-muted-foreground transition-colors hover:text-foreground">Visa Guide</Link>
            <Link href="/counsellor" className="text-muted-foreground transition-colors hover:text-foreground">Counsellor</Link>
          </nav>

          <p className="text-sm text-muted-foreground">
            UniGuide 2026. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}
