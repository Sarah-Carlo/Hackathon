"use client"

import { useState, useRef, useEffect } from "react"
import { ArrowLeft, Send, Star, Paperclip } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import type { Counsellor } from "@/lib/counsellor-data"

interface Message {
  id: string
  sender: "user" | "counsellor"
  text: string
  timestamp: Date
}

interface CounsellorChatProps {
  counsellor: Counsellor
  onBack: () => void
}

const autoReplies = [
  "Thank you for reaching out! I'd be happy to help you with your study abroad plans. Could you tell me about your academic background?",
  "That's great! Based on your profile, there are several universities that could be a strong fit. What countries are you most interested in?",
  "Excellent choice! I have extensive experience with admissions to universities in those regions. Let me share some key factors to consider.",
  "For your CGPA and IELTS score, you have competitive options. I'd recommend looking into programs that align with your career goals.",
  "I can help you prepare a strong application. Would you like guidance on your Statement of Purpose or Letters of Recommendation?",
  "The visa process for that country typically takes a few weeks. I can walk you through each step to make sure everything goes smoothly.",
  "That's a common concern. Let me explain the financial requirements and some options that might work within your budget.",
  "Great question! I'll send you a detailed checklist. Feel free to ask about any specific documents you're unsure about.",
]

export function CounsellorChat({ counsellor, onBack }: CounsellorChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      sender: "counsellor",
      text: `Hello! I'm ${counsellor.name}, ${counsellor.title}. I specialize in ${counsellor.specialization}. How can I help you today with your study abroad journey?`,
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [replyIndex, setReplyIndex] = useState(0)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  function handleSend(e: React.FormEvent) {
    e.preventDefault()
    if (!input.trim()) return

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      sender: "user",
      text: input.trim(),
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMsg])
    setInput("")

    setTimeout(() => {
      const reply: Message = {
        id: `counsellor-${Date.now()}`,
        sender: "counsellor",
        text: autoReplies[replyIndex % autoReplies.length],
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, reply])
      setReplyIndex((i) => i + 1)
    }, 1200)
  }

  return (
    <div className="flex flex-col rounded-xl border bg-card overflow-hidden" style={{ height: "calc(100vh - 200px)" }}>
      {/* Header */}
      <div className="flex items-center gap-3 border-b bg-card px-4 py-3">
        <Button variant="ghost" size="icon" onClick={onBack} aria-label="Go back">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <Avatar className="h-10 w-10 border-2 border-primary/20">
          <AvatarFallback className="bg-primary/10 font-heading text-sm font-bold text-primary">
            {counsellor.avatar}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <h2 className="font-heading text-sm font-semibold text-foreground">{counsellor.name}</h2>
          <p className="flex items-center gap-1 text-xs text-muted-foreground">
            <Star className="h-3 w-3 fill-chart-4 text-chart-4" />
            {counsellor.rating} | {counsellor.specialization}
          </p>
        </div>
        <span className="flex items-center gap-1.5 text-xs font-medium text-chart-2">
          <span className="h-2 w-2 rounded-full bg-chart-2" />
          Online
        </span>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-2.5 ${
                  msg.sender === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-foreground"
                }`}
              >
                <p className="text-sm leading-relaxed">{msg.text}</p>
                <p className={`mt-1 text-right text-[10px] ${msg.sender === "user" ? "text-primary-foreground/60" : "text-muted-foreground"}`}>
                  {msg.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </p>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="border-t bg-card p-3">
        <form onSubmit={handleSend} className="flex items-center gap-2">
          <Button type="button" variant="ghost" size="icon" className="shrink-0" aria-label="Attach file">
            <Paperclip className="h-4 w-4" />
          </Button>
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your message..."
            className="flex-1"
          />
          <Button type="submit" size="icon" className="shrink-0" aria-label="Send message">
            <Send className="h-4 w-4" />
          </Button>
        </form>
        <p className="mt-2 text-center text-[11px] text-muted-foreground">
          This is a live chat with a human counsellor. Response times may vary.
        </p>
      </div>
    </div>
  )
}
