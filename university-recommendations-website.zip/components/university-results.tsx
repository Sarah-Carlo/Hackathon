"use client"

import { Briefcase, DollarSign, GraduationCap, MapPin, TrendingUp } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import type { RecommendationResult } from "@/app/university-finder/page"

interface UniversityResultsProps {
  results: RecommendationResult[] | null
  userProfile: {
    cgpa: number
    ielts: number
    budget: number
    countries: string[]
    career: string
  } | null
}

export function UniversityResults({ results, userProfile }: UniversityResultsProps) {
  if (!results) {
    return (
      <div className="flex min-h-[400px] flex-col items-center justify-center rounded-xl border bg-card p-10 text-center">
        <GraduationCap className="mb-4 h-12 w-12 text-muted-foreground/40" />
        <h3 className="font-heading text-lg font-semibold text-foreground">No results yet</h3>
        <p className="mt-2 max-w-sm text-sm text-muted-foreground">
          Fill in your academic profile on the left and click &quot;Find Universities&quot; to see personalized recommendations.
        </p>
      </div>
    )
  }

  if (results.length === 0) {
    return (
      <div className="flex min-h-[400px] flex-col items-center justify-center rounded-xl border bg-card p-10 text-center">
        <GraduationCap className="mb-4 h-12 w-12 text-muted-foreground/40" />
        <h3 className="font-heading text-lg font-semibold text-foreground">No matches found</h3>
        <p className="mt-2 max-w-sm text-sm text-muted-foreground">
          Try adjusting your budget, country preferences, or career goals to see more results.
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="font-heading text-xl font-semibold text-foreground">
          {results.length} {results.length === 1 ? "University" : "Universities"} Found
        </h2>
        {userProfile && (
          <span className="text-sm text-muted-foreground">
            CGPA: {userProfile.cgpa} | IELTS: {userProfile.ielts}
          </span>
        )}
      </div>

      {results.map(({ university, admissionProbability }, index) => (
        <div
          key={university.id}
          className="rounded-xl border bg-card p-6 transition-all hover:border-primary/30 hover:shadow-md"
        >
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
                  {index + 1}
                </span>
                <h3 className="font-heading text-lg font-semibold text-foreground">
                  {university.name}
                </h3>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{university.description}</p>
            </div>

            <div className="flex flex-col items-center rounded-lg bg-background px-4 py-3">
              <span className="text-xs text-muted-foreground">Admission Chance</span>
              <span
                className={`text-2xl font-bold ${
                  admissionProbability >= 60
                    ? "text-chart-2"
                    : admissionProbability >= 30
                    ? "text-chart-4"
                    : "text-destructive"
                }`}
              >
                {admissionProbability}%
              </span>
              <Progress value={admissionProbability} className="mt-1 h-1.5 w-20" />
            </div>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <div className="flex items-center gap-2 text-sm">
              <MapPin className="h-4 w-4 text-muted-foreground" />
              <span className="text-foreground">{university.country}</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <DollarSign className="h-4 w-4 text-muted-foreground" />
              <span className="text-foreground">${university.tuitionUSD.toLocaleString()}/yr</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
              <span className="text-foreground">ROI: {university.roiScore}/100</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Briefcase className="h-4 w-4 text-muted-foreground" />
              <Badge
                variant={university.jobDemand === "High" ? "default" : "secondary"}
                className="text-xs"
              >
                {university.jobDemand} Demand
              </Badge>
            </div>
          </div>

          <div className="mt-3 flex flex-wrap gap-1.5">
            {university.programs.map((program) => (
              <span
                key={program}
                className="rounded-md bg-secondary px-2 py-0.5 text-xs font-medium text-secondary-foreground"
              >
                {program}
              </span>
            ))}
          </div>

          <div className="mt-4 text-xs text-muted-foreground">
            World Ranking: #{university.ranking} | Min CGPA: {university.minCGPA}/10 | Min IELTS: {university.minIELTS}
          </div>
        </div>
      ))}
    </div>
  )
}
