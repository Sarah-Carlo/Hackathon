import { BarChart3, BookOpen, FileCheck, Globe, MapPin, TrendingUp } from "lucide-react"

const features = [
  {
    icon: BarChart3,
    title: "Admission Probability",
    description: "Get your personalized admission chances based on CGPA, IELTS score, and university requirements.",
  },
  {
    icon: TrendingUp,
    title: "ROI Ranking",
    description: "Compare universities by return on investment, including tuition costs and post-graduation salary data.",
  },
  {
    icon: MapPin,
    title: "Job Demand Insights",
    description: "Discover in-demand careers and job market trends in your preferred study destinations.",
  },
  {
    icon: FileCheck,
    title: "Document Checklist",
    description: "Stay organized with a comprehensive checklist of required documents for your applications.",
  },
  {
    icon: Globe,
    title: "Visa Guidance",
    description: "Step-by-step visa application guidance for every country with timeline and requirements.",
  },
  {
    icon: BookOpen,
    title: "Application Support",
    description: "Expert guidance through every step of your university application process.",
  },
]

export function FeaturesSection() {
  return (
    <section className="border-t bg-card px-4 py-20 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="text-center">
          <h2 className="font-heading text-3xl font-bold text-foreground md:text-4xl text-balance">
            Everything You Need for Your Study Abroad Journey
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            Our comprehensive platform guides you from university selection to visa approval.
          </p>
        </div>

        <div className="mt-14 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="group rounded-xl border bg-background p-6 transition-all hover:border-primary/30 hover:shadow-md"
            >
              <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10">
                <feature.icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-heading text-lg font-semibold text-foreground">
                {feature.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
