import Link from "next/link"
import { ArrowRight, GraduationCap, Globe, Users } from "lucide-react"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden px-4 py-20 lg:px-8 lg:py-32">
      <div className="mx-auto max-w-7xl">
        <div className="flex flex-col items-center text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border bg-card px-4 py-1.5 text-sm text-muted-foreground">
            <Globe className="h-4 w-4" />
            <span>Trusted by 10,000+ students worldwide</span>
          </div>

          <h1 className="max-w-4xl font-heading text-4xl font-bold leading-tight tracking-tight text-foreground md:text-5xl lg:text-6xl text-balance">
            Find Your Perfect University Match
          </h1>

          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-muted-foreground">
            Get personalized university recommendations based on your academic profile, budget, and career aspirations. Our smart matching system analyzes thousands of programs to find the best fit for you.
          </p>

          <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row">
            <Button asChild size="lg" className="gap-2 px-8 text-base">
              <Link href="/university-finder">
                Get Recommendations
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="gap-2 px-8 text-base">
              <Link href="/counsellor">
                Talk to a Counsellor
              </Link>
            </Button>
          </div>

          <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-3">
            <div className="flex flex-col items-center gap-2 rounded-xl border bg-card p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <GraduationCap className="h-6 w-6 text-primary" />
              </div>
              <span className="text-2xl font-bold text-foreground">500+</span>
              <span className="text-sm text-muted-foreground">Universities Listed</span>
            </div>
            <div className="flex flex-col items-center gap-2 rounded-xl border bg-card p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-accent">
                <Globe className="h-6 w-6 text-accent-foreground" />
              </div>
              <span className="text-2xl font-bold text-foreground">30+</span>
              <span className="text-sm text-muted-foreground">Countries Covered</span>
            </div>
            <div className="flex flex-col items-center gap-2 rounded-xl border bg-card p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-secondary">
                <Users className="h-6 w-6 text-secondary-foreground" />
              </div>
              <span className="text-2xl font-bold text-foreground">10K+</span>
              <span className="text-sm text-muted-foreground">Students Guided</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
