"use client"

import { useState } from "react"
import { Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { universities, countries, careerFields, calculateAdmissionProbability } from "@/lib/university-data"
import type { RecommendationResult } from "@/app/university-finder/page"

interface UniversityFormProps {
  onResults: (
    results: RecommendationResult[],
    profile: { cgpa: number; ielts: number; budget: number; countries: string[]; career: string }
  ) => void
}

export function UniversityForm({ onResults }: UniversityFormProps) {
  const [cgpa, setCgpa] = useState("")
  const [ielts, setIelts] = useState("")
  const [budget, setBudget] = useState("")
  const [selectedCountries, setSelectedCountries] = useState<string[]>([])
  const [career, setCareer] = useState("")
  const [linkedin, setLinkedin] = useState("")

  function toggleCountry(country: string) {
    setSelectedCountries((prev) =>
      prev.includes(country) ? prev.filter((c) => c !== country) : [...prev, country]
    )
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    const cgpaNum = parseFloat(cgpa)
    const ieltsNum = parseFloat(ielts)
    const budgetNum = parseInt(budget) || 999999

    const filtered = universities.filter((uni) => {
      const countryMatch = selectedCountries.length === 0 || selectedCountries.includes(uni.country)
      const budgetMatch = uni.tuitionUSD <= budgetNum
      const careerMatch = !career || uni.programs.includes(career)
      return countryMatch && budgetMatch && careerMatch
    })

    const results: RecommendationResult[] = filtered
      .map((uni) => ({
        university: uni,
        admissionProbability: calculateAdmissionProbability(uni, cgpaNum, ieltsNum),
      }))
      .sort((a, b) => b.admissionProbability - a.admissionProbability)

    onResults(results, {
      cgpa: cgpaNum,
      ielts: ieltsNum,
      budget: budgetNum,
      countries: selectedCountries,
      career,
    })
  }

  return (
    <form onSubmit={handleSubmit} className="sticky top-20 space-y-5 rounded-xl border bg-card p-6">
      <h2 className="font-heading text-xl font-semibold text-foreground">Your Profile</h2>

      <div className="space-y-2">
        <Label htmlFor="cgpa">CGPA (out of 10)</Label>
        <Input
          id="cgpa"
          type="number"
          step="0.1"
          min="0"
          max="10"
          placeholder="e.g. 8.5"
          value={cgpa}
          onChange={(e) => setCgpa(e.target.value)}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="ielts">IELTS Score</Label>
        <Input
          id="ielts"
          type="number"
          step="0.5"
          min="0"
          max="9"
          placeholder="e.g. 7.0"
          value={ielts}
          onChange={(e) => setIelts(e.target.value)}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="budget">Annual Budget (USD)</Label>
        <Input
          id="budget"
          type="number"
          min="0"
          placeholder="e.g. 40000"
          value={budget}
          onChange={(e) => setBudget(e.target.value)}
        />
      </div>

      <div className="space-y-2">
        <Label>Preferred Countries</Label>
        <div className="grid grid-cols-2 gap-2">
          {countries.map((country) => (
            <label key={country} className="flex cursor-pointer items-center gap-2 rounded-md border bg-background px-3 py-2 text-sm transition-colors hover:bg-muted">
              <Checkbox
                checked={selectedCountries.includes(country)}
                onCheckedChange={() => toggleCountry(country)}
              />
              <span className="text-foreground">{country}</span>
            </label>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="career">Career Goal</Label>
        <Select value={career} onValueChange={setCareer}>
          <SelectTrigger id="career">
            <SelectValue placeholder="Select career field" />
          </SelectTrigger>
          <SelectContent>
            {careerFields.map((field) => (
              <SelectItem key={field} value={field}>
                {field}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="linkedin">LinkedIn Profile (optional)</Label>
        <Input
          id="linkedin"
          type="url"
          placeholder="https://linkedin.com/in/..."
          value={linkedin}
          onChange={(e) => setLinkedin(e.target.value)}
        />
      </div>

      <Button type="submit" className="w-full gap-2" size="lg">
        <Search className="h-4 w-4" />
        Find Universities
      </Button>
    </form>
  )
}
