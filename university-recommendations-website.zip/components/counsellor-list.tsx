"use client"

import { MessageCircle, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { counsellors } from "@/lib/counsellor-data"

interface CounsellorListProps {
  onSelect: (id: number) => void
}

export function CounsellorList({ onSelect }: CounsellorListProps) {
  return (
    <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
      {counsellors.map((counsellor) => (
        <div
          key={counsellor.id}
          className="flex flex-col gap-4 rounded-xl border bg-card p-6 transition-all hover:border-primary/30 hover:shadow-md"
        >
          <div className="flex items-start gap-4">
            <Avatar className="h-14 w-14 border-2 border-primary/20">
              <AvatarFallback className="bg-primary/10 font-heading text-sm font-bold text-primary">
                {counsellor.avatar}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h3 className="font-heading text-lg font-semibold text-foreground">
                {counsellor.name}
              </h3>
              <p className="text-sm text-muted-foreground">{counsellor.title}</p>
              <p className="mt-1 text-sm font-medium text-primary">{counsellor.specialization}</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1">
              <Star className="h-4 w-4 fill-chart-4 text-chart-4" />
              {counsellor.rating} ({counsellor.reviews} reviews)
            </span>
            <span>{counsellor.experience} experience</span>
          </div>

          <div className="flex flex-wrap gap-2">
            {counsellor.languages.map((lang) => (
              <span key={lang} className="rounded-md bg-secondary px-2.5 py-1 text-xs font-medium text-secondary-foreground">
                {lang}
              </span>
            ))}
          </div>

          <div className="mt-auto flex items-center justify-between">
            <span className={`text-sm font-medium ${counsellor.availability === "Available Now" ? "text-chart-2" : "text-muted-foreground"}`}>
              {counsellor.availability}
            </span>
            <Button size="sm" className="gap-2" onClick={() => onSelect(counsellor.id)}>
              <MessageCircle className="h-4 w-4" />
              Start Chat
            </Button>
          </div>
        </div>
      ))}
    </div>
  )
}
