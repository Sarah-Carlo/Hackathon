"use client"

import { useSearchParams } from "next/navigation"
import { useState, Suspense } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { CounsellorList } from "@/components/counsellor-list"
import { CounsellorChat } from "@/components/counsellor-chat"
import { counsellors } from "@/lib/counsellor-data"

function CounsellorContent() {
  const searchParams = useSearchParams()
  const initialId = searchParams.get("id")
  const [selectedId, setSelectedId] = useState<number | null>(
    initialId ? parseInt(initialId) : null
  )

  const selectedCounsellor = counsellors.find((c) => c.id === selectedId) || null

  return (
    <main className="mx-auto max-w-7xl flex-1 px-4 py-8 lg:px-8">
      {!selectedCounsellor ? (
        <>
          <div className="mb-10 text-center">
            <h1 className="font-heading text-3xl font-bold text-foreground md:text-4xl text-balance">
              Consult a Counsellor
            </h1>
            <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
              Choose an expert counsellor and start a live chat for personalized guidance on university admissions, visa applications, and more.
            </p>
          </div>
          <CounsellorList onSelect={setSelectedId} />
        </>
      ) : (
        <CounsellorChat
          counsellor={selectedCounsellor}
          onBack={() => setSelectedId(null)}
        />
      )}
    </main>
  )
}

export default function CounsellorPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <Suspense fallback={
        <div className="flex flex-1 items-center justify-center">
          <p className="text-muted-foreground">Loading...</p>
        </div>
      }>
        <CounsellorContent />
      </Suspense>
      <Footer />
    </div>
  )
}
