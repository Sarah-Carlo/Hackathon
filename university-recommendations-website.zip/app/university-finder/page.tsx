"use client"

import { useState } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { UniversityForm } from "@/components/university-form"
import { UniversityResults } from "@/components/university-results"
import type { University } from "@/lib/university-data"

export interface RecommendationResult {
  university: University
  admissionProbability: number
}

export default function UniversityFinderPage() {
  const [results, setResults] = useState<RecommendationResult[] | null>(null)
  const [userProfile, setUserProfile] = useState<{
    cgpa: number
    ielts: number
    budget: number
    countries: string[]
    career: string
  } | null>(null)

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="mx-auto max-w-7xl px-4 py-12 lg:px-8">
        <div className="mb-10 text-center">
          <h1 className="font-heading text-3xl font-bold text-foreground md:text-4xl text-balance">
            University Finder
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
            Enter your academic profile to receive personalized university recommendations with admission probabilities and ROI analysis.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-10 lg:grid-cols-5">
          <div className="lg:col-span-2">
            <UniversityForm
              onResults={(r, profile) => {
                setResults(r)
                setUserProfile(profile)
              }}
            />
          </div>
          <div className="lg:col-span-3">
            <UniversityResults results={results} userProfile={userProfile} />
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
