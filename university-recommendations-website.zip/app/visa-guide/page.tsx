"use client"

import { useState } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { ChevronDown, ChevronUp, Clock, DollarSign, FileText, Globe, MapPin } from "lucide-react"

interface VisaInfo {
  country: string
  visaType: string
  processingTime: string
  fee: string
  steps: string[]
  requirements: string[]
  tips: string[]
}

const visaData: VisaInfo[] = [
  {
    country: "USA",
    visaType: "F-1 Student Visa",
    processingTime: "3-5 months",
    fee: "$185 (SEVIS: $350)",
    steps: [
      "Receive I-20 from your university",
      "Pay SEVIS I-901 fee",
      "Complete DS-160 online application",
      "Pay the visa application fee",
      "Schedule and attend visa interview at US Embassy",
      "Wait for visa processing and passport return",
    ],
    requirements: [
      "Valid passport (6+ months validity)",
      "I-20 form from SEVP-certified school",
      "DS-160 confirmation page",
      "Visa application fee receipt",
      "SEVIS fee receipt",
      "Passport-size photograph",
      "Financial documents proving ability to pay",
      "Academic transcripts and test scores",
    ],
    tips: [
      "Apply at least 120 days before your program start date",
      "Prepare clear, concise answers about your study plans",
      "Bring organized documents to your interview",
      "Demonstrate strong ties to your home country",
    ],
  },
  {
    country: "UK",
    visaType: "Student Visa (Tier 4)",
    processingTime: "3-6 weeks",
    fee: "GBP 490 + IHS surcharge",
    steps: [
      "Receive CAS (Confirmation of Acceptance for Studies) from university",
      "Complete online visa application",
      "Pay visa fee and Immigration Health Surcharge",
      "Book and attend biometrics appointment",
      "Submit supporting documents",
      "Wait for decision (usually 3 weeks)",
    ],
    requirements: [
      "Valid CAS reference number",
      "Valid passport",
      "Proof of English language proficiency",
      "Proof of financial support (tuition + living costs for 9 months)",
      "TB test results (from certain countries)",
      "Academic qualifications referenced in CAS",
    ],
    tips: [
      "You can apply up to 6 months before your course starts",
      "Funds must be held for 28 consecutive days",
      "Consider the Immigration Health Surcharge in your budget",
    ],
  },
  {
    country: "Canada",
    visaType: "Study Permit",
    processingTime: "4-16 weeks",
    fee: "CAD 150 + Biometrics CAD 85",
    steps: [
      "Receive Letter of Acceptance from DLI",
      "Create GCKey account on IRCC portal",
      "Complete online study permit application",
      "Pay fees and schedule biometrics",
      "Submit documents and attend biometrics appointment",
      "Wait for approval and obtain port-of-entry letter",
    ],
    requirements: [
      "Letter of Acceptance from Designated Learning Institution",
      "Valid passport",
      "Proof of financial support",
      "Passport photographs",
      "Immigration medical exam (if required)",
      "Police clearance certificate",
      "Statement of Purpose",
    ],
    tips: [
      "Apply through the Student Direct Stream (SDS) for faster processing",
      "Get a co-op work permit if your program includes work placement",
      "Consider post-graduation work permit eligibility",
    ],
  },
  {
    country: "Australia",
    visaType: "Student Visa (Subclass 500)",
    processingTime: "4-6 weeks",
    fee: "AUD 710",
    steps: [
      "Receive CoE (Confirmation of Enrolment) from institution",
      "Create ImmiAccount on Australian immigration portal",
      "Complete online visa application",
      "Arrange health insurance (OSHC)",
      "Complete health examinations",
      "Submit biometrics and documents",
    ],
    requirements: [
      "Confirmation of Enrolment (CoE)",
      "Valid passport",
      "Genuine Temporary Entrant (GTE) statement",
      "English proficiency proof",
      "Financial capacity evidence",
      "Overseas Student Health Cover (OSHC)",
      "Health and character requirements",
    ],
    tips: [
      "Start the GTE statement early as it requires careful preparation",
      "Book health exams as soon as possible to avoid delays",
      "Apply at least 6 weeks before your course starts",
    ],
  },
  {
    country: "Germany",
    visaType: "National Visa for Study Purposes",
    processingTime: "6-12 weeks",
    fee: "EUR 75",
    steps: [
      "Receive admission letter from German university",
      "Open a blocked account (Sperrkonto) with required funds",
      "Book an appointment at the German Embassy",
      "Complete visa application form",
      "Attend visa interview with all documents",
      "Wait for processing and collect visa",
    ],
    requirements: [
      "University admission letter",
      "Valid passport",
      "Blocked account proof (EUR 11,208/year)",
      "Health insurance coverage",
      "Academic certificates and transcripts",
      "Proof of German/English language proficiency",
      "Motivation letter",
    ],
    tips: [
      "Open the blocked account well in advance as it takes time",
      "Embassy appointments can have long wait times, book early",
      "Many programs are tuition-free; budget mainly for living costs",
    ],
  },
]

export default function VisaGuidePage() {
  const [expanded, setExpanded] = useState<string | null>(null)

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="mx-auto max-w-4xl px-4 py-12 lg:px-8">
        <div className="mb-10 text-center">
          <h1 className="font-heading text-3xl font-bold text-foreground md:text-4xl text-balance">
            Visa & Application Guide
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
            Comprehensive visa guides for popular study abroad destinations. Click on a country to see detailed step-by-step instructions.
          </p>
        </div>

        <div className="space-y-4">
          {visaData.map((visa) => {
            const isOpen = expanded === visa.country
            return (
              <div key={visa.country} className="rounded-xl border bg-card overflow-hidden">
                <button
                  type="button"
                  onClick={() => setExpanded(isOpen ? null : visa.country)}
                  className="flex w-full items-center justify-between p-6 text-left transition-colors hover:bg-muted/50"
                >
                  <div className="flex items-center gap-4">
                    <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10">
                      <Globe className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h2 className="font-heading text-lg font-semibold text-foreground">{visa.country}</h2>
                      <p className="text-sm text-muted-foreground">{visa.visaType}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="hidden items-center gap-4 text-sm text-muted-foreground sm:flex">
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {visa.processingTime}
                      </span>
                      <span className="flex items-center gap-1">
                        <DollarSign className="h-4 w-4" />
                        {visa.fee}
                      </span>
                    </div>
                    {isOpen ? (
                      <ChevronUp className="h-5 w-5 text-muted-foreground" />
                    ) : (
                      <ChevronDown className="h-5 w-5 text-muted-foreground" />
                    )}
                  </div>
                </button>

                {isOpen && (
                  <div className="border-t px-6 py-6 space-y-6">
                    <div className="flex flex-wrap gap-4 text-sm sm:hidden">
                      <span className="flex items-center gap-1 text-muted-foreground">
                        <Clock className="h-4 w-4" />
                        {visa.processingTime}
                      </span>
                      <span className="flex items-center gap-1 text-muted-foreground">
                        <DollarSign className="h-4 w-4" />
                        {visa.fee}
                      </span>
                    </div>

                    <div>
                      <h3 className="mb-3 flex items-center gap-2 font-heading text-base font-semibold text-foreground">
                        <MapPin className="h-4 w-4 text-primary" />
                        Application Steps
                      </h3>
                      <ol className="space-y-2">
                        {visa.steps.map((step, i) => (
                          <li key={i} className="flex gap-3 text-sm">
                            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
                              {i + 1}
                            </span>
                            <span className="text-foreground">{step}</span>
                          </li>
                        ))}
                      </ol>
                    </div>

                    <div>
                      <h3 className="mb-3 flex items-center gap-2 font-heading text-base font-semibold text-foreground">
                        <FileText className="h-4 w-4 text-primary" />
                        Required Documents
                      </h3>
                      <ul className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                        {visa.requirements.map((req, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm">
                            <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                            <span className="text-foreground">{req}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="rounded-lg bg-accent/50 p-4">
                      <h3 className="mb-2 font-heading text-sm font-semibold text-accent-foreground">
                        Tips
                      </h3>
                      <ul className="space-y-1.5">
                        {visa.tips.map((tip, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-accent-foreground">
                            <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-accent-foreground/50" />
                            {tip}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </main>
      <Footer />
    </div>
  )
}
