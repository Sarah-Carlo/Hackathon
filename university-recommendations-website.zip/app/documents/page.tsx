"use client"

import { useState } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { CheckCircle2, Circle, FileText, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"

interface DocumentItem {
  id: string
  name: string
  description: string
  category: string
}

const documentCategories = [
  {
    title: "Academic Documents",
    items: [
      { id: "transcript", name: "Official Academic Transcripts", description: "Certified transcripts from all attended institutions", category: "academic" },
      { id: "degree", name: "Degree Certificates", description: "Copies of all earned degrees and certificates", category: "academic" },
      { id: "sop", name: "Statement of Purpose (SOP)", description: "Personal essay outlining academic and career goals", category: "academic" },
      { id: "lor", name: "Letters of Recommendation (2-3)", description: "Academic or professional recommendations", category: "academic" },
      { id: "cv", name: "Academic CV / Resume", description: "Detailed academic and professional history", category: "academic" },
    ],
  },
  {
    title: "Test Scores",
    items: [
      { id: "ielts", name: "IELTS / TOEFL Score Report", description: "Official English language proficiency test results", category: "tests" },
      { id: "gre", name: "GRE / GMAT Score Report", description: "Standardized test scores (if required)", category: "tests" },
      { id: "sat", name: "SAT / ACT Scores", description: "Undergraduate standardized test scores (if applicable)", category: "tests" },
    ],
  },
  {
    title: "Identity & Legal Documents",
    items: [
      { id: "passport", name: "Valid Passport", description: "Must be valid for at least 6 months beyond intended stay", category: "identity" },
      { id: "photos", name: "Passport-Size Photographs", description: "Recent photographs meeting embassy specifications", category: "identity" },
      { id: "birth", name: "Birth Certificate", description: "Official birth certificate with translation if needed", category: "identity" },
    ],
  },
  {
    title: "Financial Documents",
    items: [
      { id: "bank", name: "Bank Statements (6 months)", description: "Proof of financial ability to cover tuition and living costs", category: "financial" },
      { id: "sponsor", name: "Sponsorship Letter", description: "If funded by a sponsor, official letter confirming support", category: "financial" },
      { id: "affidavit", name: "Financial Affidavit", description: "Sworn statement of financial support", category: "financial" },
    ],
  },
  {
    title: "Additional Documents",
    items: [
      { id: "work", name: "Work Experience Certificate", description: "Letters from employers confirming work experience", category: "additional" },
      { id: "portfolio", name: "Portfolio / Writing Samples", description: "For creative or research-based programs", category: "additional" },
      { id: "medical", name: "Medical Examination Report", description: "Health check results as required by the destination", category: "additional" },
      { id: "insurance", name: "Health Insurance Proof", description: "Coverage documentation for the study period", category: "additional" },
    ],
  },
]

export default function DocumentsPage() {
  const [checked, setChecked] = useState<Record<string, boolean>>({})

  const allItems = documentCategories.flatMap((c) => c.items)
  const checkedCount = Object.values(checked).filter(Boolean).length
  const totalCount = allItems.length
  const progressPercent = totalCount > 0 ? Math.round((checkedCount / totalCount) * 100) : 0

  function toggleItem(id: string) {
    setChecked((prev) => ({ ...prev, [id]: !prev[id] }))
  }

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="mx-auto max-w-4xl px-4 py-12 lg:px-8">
        <div className="mb-10 text-center">
          <h1 className="font-heading text-3xl font-bold text-foreground md:text-4xl text-balance">
            Document Checklist
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
            Keep track of all the documents you need for your university applications.
          </p>
        </div>

        <div className="mb-8 rounded-xl border bg-card p-6">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-sm text-muted-foreground">Progress</span>
              <p className="font-heading text-2xl font-bold text-foreground">
                {checkedCount} / {totalCount} completed
              </p>
            </div>
            <span className="text-3xl font-bold text-primary">{progressPercent}%</span>
          </div>
          <Progress value={progressPercent} className="mt-3 h-2.5" />
        </div>

        <div className="space-y-8">
          {documentCategories.map((category) => (
            <div key={category.title}>
              <h2 className="mb-4 flex items-center gap-2 font-heading text-lg font-semibold text-foreground">
                <FileText className="h-5 w-5 text-primary" />
                {category.title}
              </h2>
              <div className="space-y-2">
                {category.items.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => toggleItem(item.id)}
                    className={`flex w-full items-start gap-3 rounded-lg border p-4 text-left transition-all ${
                      checked[item.id]
                        ? "border-chart-2/40 bg-chart-2/5"
                        : "bg-card hover:border-primary/30"
                    }`}
                  >
                    {checked[item.id] ? (
                      <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-chart-2" />
                    ) : (
                      <Circle className="mt-0.5 h-5 w-5 shrink-0 text-muted-foreground" />
                    )}
                    <div>
                      <p className={`font-medium ${checked[item.id] ? "text-chart-2 line-through" : "text-foreground"}`}>
                        {item.name}
                      </p>
                      <p className="mt-0.5 text-sm text-muted-foreground">{item.description}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 flex justify-center">
          <Button variant="outline" className="gap-2" onClick={() => window.print()}>
            <Download className="h-4 w-4" />
            Print Checklist
          </Button>
        </div>
      </main>
      <Footer />
    </div>
  )
}
