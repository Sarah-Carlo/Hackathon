export interface Counsellor {
  id: number
  name: string
  title: string
  specialization: string
  experience: string
  rating: number
  reviews: number
  availability: string
  languages: string[]
  avatar: string
}

export const counsellors: Counsellor[] = [
  {
    id: 1,
    name: "Dr. Sarah Mitchell",
    title: "Senior Admissions Consultant",
    specialization: "USA & Canada Universities",
    experience: "12 years",
    rating: 4.9,
    reviews: 324,
    availability: "Available Now",
    languages: ["English", "French"],
    avatar: "SM",
  },
  {
    id: 2,
    name: "Prof. James Chen",
    title: "Education Strategist",
    specialization: "UK & Europe Universities",
    experience: "8 years",
    rating: 4.8,
    reviews: 218,
    availability: "Available in 15 min",
    languages: ["English", "Mandarin"],
    avatar: "JC",
  },
  {
    id: 3,
    name: "Dr. Priya Sharma",
    title: "Career Counsellor",
    specialization: "Australia & Singapore Universities",
    experience: "10 years",
    rating: 4.7,
    reviews: 189,
    availability: "Available Now",
    languages: ["English", "Hindi"],
    avatar: "PS",
  },
  {
    id: 4,
    name: "Michael Thompson",
    title: "Visa & Documentation Expert",
    specialization: "All Countries - Visa Guidance",
    experience: "15 years",
    rating: 4.9,
    reviews: 412,
    availability: "Available in 30 min",
    languages: ["English", "Spanish"],
    avatar: "MT",
  },
]
