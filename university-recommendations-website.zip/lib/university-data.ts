export interface University {
  id: number
  name: string
  country: string
  ranking: number
  minCGPA: number
  minIELTS: number
  tuitionUSD: number
  admissionRate: number
  programs: string[]
  jobDemand: "High" | "Medium" | "Low"
  roiScore: number
  description: string
}

export const universities: University[] = [
  {
    id: 1,
    name: "Massachusetts Institute of Technology",
    country: "USA",
    ranking: 1,
    minCGPA: 9.0,
    minIELTS: 7.5,
    tuitionUSD: 57986,
    admissionRate: 4,
    programs: ["Computer Science", "Engineering", "Data Science", "AI/ML"],
    jobDemand: "High",
    roiScore: 96,
    description: "World-renowned institute for science, technology, and innovation research.",
  },
  {
    id: 2,
    name: "University of Oxford",
    country: "UK",
    ranking: 3,
    minCGPA: 8.5,
    minIELTS: 7.0,
    tuitionUSD: 39000,
    admissionRate: 15,
    programs: ["Business", "Medicine", "Law", "Computer Science"],
    jobDemand: "High",
    roiScore: 92,
    description: "One of the oldest and most prestigious universities with world-class research.",
  },
  {
    id: 3,
    name: "University of Toronto",
    country: "Canada",
    ranking: 18,
    minCGPA: 7.5,
    minIELTS: 6.5,
    tuitionUSD: 45900,
    admissionRate: 43,
    programs: ["Engineering", "Business", "Data Science", "Computer Science"],
    jobDemand: "High",
    roiScore: 88,
    description: "Canada's top university offering strong research and co-op programs.",
  },
  {
    id: 4,
    name: "ETH Zurich",
    country: "Switzerland",
    ranking: 7,
    minCGPA: 8.0,
    minIELTS: 7.0,
    tuitionUSD: 1500,
    admissionRate: 27,
    programs: ["Engineering", "Computer Science", "Physics", "Mathematics"],
    jobDemand: "High",
    roiScore: 95,
    description: "Leading European technical university with minimal tuition and excellent ROI.",
  },
  {
    id: 5,
    name: "University of Melbourne",
    country: "Australia",
    ranking: 14,
    minCGPA: 7.0,
    minIELTS: 6.5,
    tuitionUSD: 35000,
    admissionRate: 52,
    programs: ["Business", "Engineering", "Medicine", "Arts"],
    jobDemand: "Medium",
    roiScore: 82,
    description: "Top Australian university with strong industry connections and research output.",
  },
  {
    id: 6,
    name: "National University of Singapore",
    country: "Singapore",
    ranking: 8,
    minCGPA: 8.0,
    minIELTS: 6.5,
    tuitionUSD: 17500,
    admissionRate: 20,
    programs: ["Computer Science", "Engineering", "Business", "Data Science"],
    jobDemand: "High",
    roiScore: 91,
    description: "Asia's top university known for innovation, research, and industry partnerships.",
  },
  {
    id: 7,
    name: "Technical University of Munich",
    country: "Germany",
    ranking: 30,
    minCGPA: 7.5,
    minIELTS: 6.5,
    tuitionUSD: 300,
    admissionRate: 35,
    programs: ["Engineering", "Computer Science", "Physics", "AI/ML"],
    jobDemand: "High",
    roiScore: 94,
    description: "Tuition-free German university with outstanding engineering and tech programs.",
  },
  {
    id: 8,
    name: "University of British Columbia",
    country: "Canada",
    ranking: 35,
    minCGPA: 7.0,
    minIELTS: 6.5,
    tuitionUSD: 38000,
    admissionRate: 46,
    programs: ["Engineering", "Business", "Environmental Science", "Computer Science"],
    jobDemand: "Medium",
    roiScore: 84,
    description: "World-class research university set in Vancouver with diverse programs.",
  },
  {
    id: 9,
    name: "Imperial College London",
    country: "UK",
    ranking: 6,
    minCGPA: 8.5,
    minIELTS: 7.0,
    tuitionUSD: 42000,
    admissionRate: 14,
    programs: ["Engineering", "Medicine", "Computer Science", "Business"],
    jobDemand: "High",
    roiScore: 90,
    description: "Premier STEM university in London with strong industry links and research.",
  },
  {
    id: 10,
    name: "University of Amsterdam",
    country: "Netherlands",
    ranking: 53,
    minCGPA: 7.0,
    minIELTS: 6.5,
    tuitionUSD: 15000,
    admissionRate: 55,
    programs: ["Business", "Data Science", "Social Sciences", "AI/ML"],
    jobDemand: "Medium",
    roiScore: 80,
    description: "Internationally respected Dutch university with affordable tuition and great quality of life.",
  },
  {
    id: 11,
    name: "Stanford University",
    country: "USA",
    ranking: 2,
    minCGPA: 9.0,
    minIELTS: 7.5,
    tuitionUSD: 56169,
    admissionRate: 4,
    programs: ["Computer Science", "Engineering", "Business", "AI/ML"],
    jobDemand: "High",
    roiScore: 97,
    description: "Silicon Valley's premier university known for entrepreneurship and innovation.",
  },
  {
    id: 12,
    name: "University of Sydney",
    country: "Australia",
    ranking: 19,
    minCGPA: 7.0,
    minIELTS: 6.5,
    tuitionUSD: 33000,
    admissionRate: 48,
    programs: ["Business", "Engineering", "Law", "Medicine"],
    jobDemand: "Medium",
    roiScore: 81,
    description: "Australia's first university with strong programs across all disciplines.",
  },
]

export const countries = [
  "USA",
  "UK",
  "Canada",
  "Australia",
  "Germany",
  "Netherlands",
  "Switzerland",
  "Singapore",
]

export const careerFields = [
  "Computer Science",
  "Engineering",
  "Business",
  "Medicine",
  "Data Science",
  "AI/ML",
  "Law",
  "Arts",
  "Environmental Science",
  "Physics",
  "Mathematics",
  "Social Sciences",
]

export function calculateAdmissionProbability(
  university: University,
  cgpa: number,
  ielts: number
): number {
  let prob = university.admissionRate

  const cgpaDiff = cgpa - university.minCGPA
  if (cgpaDiff >= 1) prob += 15
  else if (cgpaDiff >= 0.5) prob += 10
  else if (cgpaDiff >= 0) prob += 5
  else if (cgpaDiff >= -0.5) prob -= 10
  else prob -= 25

  const ieltsDiff = ielts - university.minIELTS
  if (ieltsDiff >= 1) prob += 10
  else if (ieltsDiff >= 0.5) prob += 5
  else if (ieltsDiff >= 0) prob += 2
  else if (ieltsDiff >= -0.5) prob -= 10
  else prob -= 20

  return Math.min(95, Math.max(5, Math.round(prob)))
}
